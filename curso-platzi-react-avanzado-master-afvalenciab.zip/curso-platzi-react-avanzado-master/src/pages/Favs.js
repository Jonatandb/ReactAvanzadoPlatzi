import React from 'react';

export const Favs = () => {
  return (
    <h1>Favs</h1>
  );
};

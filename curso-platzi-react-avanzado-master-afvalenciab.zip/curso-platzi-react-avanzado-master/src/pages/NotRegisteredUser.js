import React from 'react';

export const NotRegisteredUser = () => {
  return (
    <h1>NotRegisteredUser</h1>
  );
};

import styled from 'styled-components';

export const Svg = styled.svg`
  width: 300px;
  margin-left: -35px;
  margin-top: -50px;
`;
